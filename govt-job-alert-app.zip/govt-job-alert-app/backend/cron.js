// cron.js — schedules the scraper to run automatically, forever
const cron = require("node-cron");
const { runAllScrapers } = require("./scrapers/scraper");

function startScheduler() {
  const pattern = process.env.SCRAPE_INTERVAL_CRON || "*/30 * * * *";
  console.log(`[cron] Scraper scheduled with pattern: ${pattern}`);
  cron.schedule(pattern, () => {
    runAllScrapers().catch(err => console.error("[cron] scrape run error:", err));
  });
  // Also run once immediately on startup
  runAllScrapers().catch(err => console.error("[cron] initial scrape error:", err));
}

module.exports = { startScheduler };
