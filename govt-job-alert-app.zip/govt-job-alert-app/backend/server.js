// server.js — REST API for the frontend PWA + starts the scraper scheduler
require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const { listJobs, addSubscriber } = require("./db");
const { startScheduler } = require("./cron");

const app = express();
app.use(cors());
app.use(express.json());

// Serve the PWA frontend from the same server (simplifies deployment)
app.use(express.static(path.join(__dirname, "..", "frontend")));

app.get("/api/health", (_req, res) => res.json({ ok: true, time: new Date().toISOString() }));

app.get("/api/jobs", (req, res) => {
  const { level, category, state, search, limit } = req.query;
  const jobs = listJobs({ level, category, state, search, limit: limit ? Number(limit) : 200 });
  res.json(jobs);
});

app.get("/api/vapid-public-key", (_req, res) => {
  res.json({ key: process.env.VAPID_PUBLIC_KEY || null });
});

app.post("/api/subscribe", (req, res) => {
  const sub = req.body;
  if (!sub || !sub.endpoint) return res.status(400).json({ error: "invalid subscription" });
  addSubscriber(sub);
  res.json({ ok: true });
});

// Manual trigger, handy for testing without waiting for the cron tick
app.post("/api/scrape-now", async (_req, res) => {
  const { runAllScrapers } = require("./scrapers/scraper");
  const added = await runAllScrapers();
  res.json({ addedCount: added.length });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`[server] Listening on port ${PORT}`);
  startScheduler();
});
