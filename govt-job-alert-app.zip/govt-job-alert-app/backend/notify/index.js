// notify/index.js — fan-out to every enabled channel
const { sendTelegram } = require("./telegram");
const { sendEmailDigest } = require("./email");
const { sendWebPush } = require("./webpush");

async function notifyAll(newJobs) {
  await Promise.all([
    ...newJobs.map(sendTelegram),
    sendEmailDigest(newJobs),
    sendWebPush(newJobs),
  ]);
}

module.exports = { notifyAll };
