// telegram.js — sends a message per new job via a Telegram bot
const TelegramBot = require("node-telegram-bot-api");

let bot = null;
function getBot() {
  if (!bot && process.env.TELEGRAM_BOT_TOKEN) {
    bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: false });
  }
  return bot;
}

async function sendTelegram(job) {
  if (process.env.TELEGRAM_ENABLED !== "true") return;
  const b = getBot();
  if (!b || !process.env.TELEGRAM_CHAT_ID) return;

  const text =
    `🏛️ *${job.title}*\n` +
    `Org: ${job.organization}\n` +
    `Level: ${job.level}${job.state ? " (" + job.state + ")" : ""}\n` +
    `Apply: ${job.apply_link}`;

  try {
    await b.sendMessage(process.env.TELEGRAM_CHAT_ID, text, { parse_mode: "Markdown" });
  } catch (err) {
    console.error("[telegram] send failed:", err.message);
  }
}

module.exports = { sendTelegram };
