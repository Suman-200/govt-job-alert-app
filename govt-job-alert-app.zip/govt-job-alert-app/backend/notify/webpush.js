// webpush.js — pushes a notification straight to the installed PWA / browser
const webpush = require("web-push");
const { listSubscribers } = require("../db");

function configure() {
  if (process.env.WEBPUSH_ENABLED !== "true") return false;
  if (!process.env.VAPID_PUBLIC_KEY || !process.env.VAPID_PRIVATE_KEY) return false;
  webpush.setVapidDetails(
    process.env.VAPID_SUBJECT || "mailto:example@example.com",
    process.env.VAPID_PUBLIC_KEY,
    process.env.VAPID_PRIVATE_KEY
  );
  return true;
}

async function sendWebPush(jobs) {
  if (!configure() || jobs.length === 0) return;
  const subs = listSubscribers();
  const payload = JSON.stringify({
    title: jobs.length === 1 ? jobs[0].title : `${jobs.length} new govt job notifications`,
    body: jobs.length === 1 ? jobs[0].organization : jobs.map(j => j.title).slice(0, 3).join(" • "),
    url: jobs.length === 1 ? jobs[0].apply_link : "/",
  });

  for (const sub of subs) {
    try {
      await webpush.sendNotification(sub, payload);
    } catch (err) {
      console.error("[webpush] send failed for one subscriber:", err.message);
    }
  }
}

module.exports = { sendWebPush };
