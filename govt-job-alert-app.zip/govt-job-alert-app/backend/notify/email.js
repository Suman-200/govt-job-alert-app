// email.js — sends an email digest for a batch of new jobs
const nodemailer = require("nodemailer");

function getTransport() {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 465),
    secure: Number(process.env.SMTP_PORT || 465) === 465,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
}

async function sendEmailDigest(jobs) {
  if (process.env.EMAIL_ENABLED !== "true" || jobs.length === 0) return;
  if (!process.env.SMTP_USER || !process.env.EMAIL_TO) return;

  const rows = jobs.map(j =>
    `<tr><td>${j.title}</td><td>${j.level}${j.state ? " - " + j.state : ""}</td>` +
    `<td><a href="${j.apply_link}">Apply</a></td></tr>`
  ).join("");

  const html = `
    <h2>${jobs.length} new government job notification(s)</h2>
    <table border="1" cellpadding="6" cellspacing="0">
      <tr><th>Title</th><th>Level</th><th>Link</th></tr>
      ${rows}
    </table>`;

  try {
    await getTransport().sendMail({
      from: process.env.SMTP_USER,
      to: process.env.EMAIL_TO,
      subject: `${jobs.length} new govt job notification(s)`,
      html,
    });
  } catch (err) {
    console.error("[email] send failed:", err.message);
  }
}

module.exports = { sendEmailDigest };
