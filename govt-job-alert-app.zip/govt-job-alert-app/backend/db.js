// db.js — lightweight local database (SQLite file: jobs.db)
const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(path.join(__dirname, "jobs.db"));

db.exec(`
  CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,          -- hash of source+title, used to dedupe
    title TEXT NOT NULL,
    organization TEXT,
    level TEXT,                   -- 'Central' or 'State'
    state TEXT,                   -- state name if level = State, else NULL
    category TEXT,                -- e.g. 'Banking', 'Railways', 'SSC', 'Defence', 'Teaching'
    posts INTEGER,                -- number of vacancies, if known
    qualification TEXT,
    last_date TEXT,               -- application deadline, as text (dd-mm-yyyy) if known
    apply_link TEXT NOT NULL,
    source_link TEXT,
    source_name TEXT,
    discovered_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS subscribers (
    endpoint TEXT PRIMARY KEY,
    subscription_json TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
`);

function jobExists(id) {
  return !!db.prepare("SELECT 1 FROM jobs WHERE id = ?").get(id);
}

function insertJob(job) {
  db.prepare(`
    INSERT OR IGNORE INTO jobs
    (id, title, organization, level, state, category, posts, qualification, last_date, apply_link, source_link, source_name, discovered_at)
    VALUES (@id, @title, @organization, @level, @state, @category, @posts, @qualification, @last_date, @apply_link, @source_link, @source_name, @discovered_at)
  `).run(job);
}

function listJobs({ level, category, state, search, limit = 100 } = {}) {
  let query = "SELECT * FROM jobs WHERE 1=1";
  const params = {};
  if (level) { query += " AND level = @level"; params.level = level; }
  if (category) { query += " AND category = @category"; params.category = category; }
  if (state) { query += " AND state = @state"; params.state = state; }
  if (search) { query += " AND title LIKE @search"; params.search = `%${search}%`; }
  query += " ORDER BY discovered_at DESC LIMIT @limit";
  params.limit = limit;
  return db.prepare(query).all(params);
}

function addSubscriber(sub) {
  db.prepare(`
    INSERT OR REPLACE INTO subscribers (endpoint, subscription_json, created_at)
    VALUES (?, ?, ?)
  `).run(sub.endpoint, JSON.stringify(sub), new Date().toISOString());
}

function listSubscribers() {
  return db.prepare("SELECT subscription_json FROM subscribers").all()
    .map(r => JSON.parse(r.subscription_json));
}

module.exports = { db, jobExists, insertJob, listJobs, addSubscriber, listSubscribers };
