// sources.js
//
// Each entry describes ONE government website to poll for notifications.
// IMPORTANT: government sites redesign their HTML often. The CSS selectors
// below are a starting point — after you deploy, open the target page,
// right-click a notification link -> Inspect, and adjust `rowSelector` /
// `titleSelector` / `linkSelector` to match what you actually see.
// A short guide for doing this is in README.md ("Fixing a scraper").
//
// level: "Central" | "State"
// category: free-text bucket used for filtering in the app

module.exports = [
  {
    name: "SSC (Staff Selection Commission)",
    url: "https://ssc.nic.in/Portal/Notices",
    level: "Central",
    category: "SSC",
    rowSelector: "table tr",
    titleSelector: "td:nth-child(2)",
    linkSelector: "a",
  },
  {
    name: "UPSC (Union Public Service Commission)",
    url: "https://upsc.gov.in/whats-new",
    level: "Central",
    category: "UPSC",
    rowSelector: ".view-content .views-row",
    titleSelector: "a",
    linkSelector: "a",
  },
  {
    name: "RRB (Railway Recruitment Boards)",
    url: "https://www.rrbcdg.gov.in/notification.php",
    level: "Central",
    category: "Railways",
    rowSelector: "table tr",
    titleSelector: "td",
    linkSelector: "a",
  },
  {
    name: "IBPS (Banking)",
    url: "https://www.ibps.in/",
    level: "Central",
    category: "Banking",
    rowSelector: ".notification-list li, marquee a",
    titleSelector: "a",
    linkSelector: "a",
  },
  {
    name: "Employment News (weekly gazette)",
    url: "https://employmentnews.gov.in/",
    level: "Central",
    category: "General",
    rowSelector: ".job-list li, table tr",
    titleSelector: "a",
    linkSelector: "a",
  },
  // ---- STATE EXAMPLES: duplicate this block per state you care about ----
  {
    name: "UPPSC (Uttar Pradesh)",
    url: "https://uppsc.up.nic.in/",
    level: "State",
    state: "Uttar Pradesh",
    category: "PSC",
    rowSelector: "table tr",
    titleSelector: "td",
    linkSelector: "a",
  },
  {
    name: "MPPSC (Madhya Pradesh)",
    url: "https://mppsc.mp.gov.in/",
    level: "State",
    state: "Madhya Pradesh",
    category: "PSC",
    rowSelector: "table tr",
    titleSelector: "td",
    linkSelector: "a",
  },
  // Add more states by copying a block above and changing name/url/state.
];
