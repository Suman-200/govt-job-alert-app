// scraper.js — runs all sources once, stores new jobs, fires notifications.
require("dotenv").config();
const axios = require("axios");
const cheerio = require("cheerio");
const crypto = require("crypto");
const sources = require("./sources");
const { jobExists, insertJob } = require("../db");
const { notifyAll } = require("../notify");

const DELAY = Number(process.env.REQUEST_DELAY_MS || 1500);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function makeId(sourceName, title) {
  return crypto.createHash("sha1").update(sourceName + "|" + title).digest("hex");
}

function absolute(base, href) {
  try { return new URL(href, base).toString(); } catch { return href; }
}

async function scrapeSource(src) {
  const found = [];
  try {
    const { data: html } = await axios.get(src.url, {
      timeout: 15000,
      headers: { "User-Agent": "Mozilla/5.0 (GovtJobAlertBot/1.0; +personal-use)" },
    });
    const $ = cheerio.load(html);

    $(src.rowSelector).each((_, el) => {
      const titleEl = $(el).find(src.titleSelector).first();
      const linkEl = $(el).find(src.linkSelector).first();
      const title = (titleEl.text() || "").trim().replace(/\s+/g, " ");
      let href = linkEl.attr("href");
      if (!title || !href) return;
      href = absolute(src.url, href);

      // Basic relevance filter: skip obvious non-job nav links
      if (title.length < 8) return;

      found.push({
        id: makeId(src.name, title),
        title,
        organization: src.name,
        level: src.level,
        state: src.state || null,
        category: src.category,
        posts: null,
        qualification: null,
        last_date: null,
        apply_link: href,
        source_link: src.url,
        source_name: src.name,
        discovered_at: new Date().toISOString(),
      });
    });
  } catch (err) {
    console.error(`[scraper] Failed to fetch "${src.name}": ${err.message}`);
  }
  return found;
}

async function runAllScrapers() {
  console.log(`[scraper] Run started ${new Date().toISOString()}`);
  const newlyAdded = [];

  for (const src of sources) {
    const items = await scrapeSource(src);
    for (const job of items) {
      if (!jobExists(job.id)) {
        insertJob(job);
        newlyAdded.push(job);
      }
    }
    await sleep(DELAY); // be polite to government servers
  }

  console.log(`[scraper] Run finished. ${newlyAdded.length} new notification(s) found.`);

  if (newlyAdded.length > 0) {
    await notifyAll(newlyAdded);
  }
  return newlyAdded;
}

// Allow `node scrapers/scraper.js` to run a single pass directly
if (require.main === module) {
  runAllScrapers().then(() => process.exit(0));
}

module.exports = { runAllScrapers };
