const API = ""; // same-origin; set to your backend URL if hosted separately, e.g. "https://your-api.onrender.com"

const listEl = document.getElementById("job-list");
const searchEl = document.getElementById("search");
const chipsEl = document.getElementById("level-chips");
const pushBtn = document.getElementById("enable-push");

let currentLevel = "";
let currentSearch = "";
let debounceTimer = null;

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const [d, m, y] = dateStr.split("-").map(Number);
  if (!d || !m || !y) return null;
  const target = new Date(y, m - 1, d);
  const diff = Math.ceil((target - new Date()) / (1000 * 60 * 60 * 24));
  return diff;
}

function renderJobs(jobs) {
  if (!jobs.length) {
    listEl.innerHTML = `<p class="empty">No notifications match yet. Try clearing filters, or check back after the next scrape.</p>`;
    return;
  }

  listEl.innerHTML = jobs.map((j) => {
    const isState = j.level === "State";
    const dLeft = daysUntil(j.last_date);
    const stamp = dLeft !== null && dLeft >= 0
      ? `${dLeft} day${dLeft === 1 ? "" : "s"} left`
      : "NEW";

    return `
      <article class="job-card ${isState ? "state" : ""}">
        <div class="meta-row">
          <h3>${escapeHtml(j.title)}</h3>
          <span class="stamp">${stamp}</span>
        </div>
        <p class="org">${escapeHtml(j.organization || "")}</p>
        <div class="tags">
          <span class="tag">${j.level}${j.state ? " · " + escapeHtml(j.state) : ""}</span>
          <span class="tag">${escapeHtml(j.category || "General")}</span>
        </div>
        <a class="apply-btn" href="${j.apply_link}" target="_blank" rel="noopener">Apply / View notice</a>
      </article>`;
  }).join("");
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

async function loadJobs() {
  const params = new URLSearchParams();
  if (currentLevel) params.set("level", currentLevel);
  if (currentSearch) params.set("search", currentSearch);
  try {
    const res = await fetch(`${API}/api/jobs?${params.toString()}`);
    const jobs = await res.json();
    renderJobs(jobs);
  } catch (err) {
    listEl.innerHTML = `<p class="empty">Couldn't reach the server. Check that the backend is running.</p>`;
  }
}

chipsEl.addEventListener("click", (e) => {
  const btn = e.target.closest(".chip");
  if (!btn) return;
  [...chipsEl.children].forEach((c) => c.classList.remove("active"));
  btn.classList.add("active");
  currentLevel = btn.dataset.level;
  loadJobs();
});

searchEl.addEventListener("input", (e) => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => {
    currentSearch = e.target.value.trim();
    loadJobs();
  }, 350);
});

// ---- Push notification opt-in ----
function urlBase64ToUint8Array(base64String) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
}

async function enablePush() {
  if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
    alert("Push notifications aren't supported in this browser. Try Chrome on Android.");
    return;
  }
  try {
    const reg = await navigator.serviceWorker.ready;
    const { key } = await (await fetch(`${API}/api/vapid-public-key`)).json();
    if (!key) { alert("Server hasn't configured push notifications yet."); return; }

    const sub = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(key),
    });

    await fetch(`${API}/api/subscribe`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(sub),
    });

    pushBtn.textContent = "Alerts on ✓";
    pushBtn.disabled = true;
  } catch (err) {
    console.error(err);
    alert("Couldn't enable push notifications: " + err.message);
  }
}

pushBtn.addEventListener("click", enablePush);

// ---- Register service worker (required for install + push) ----
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("service-worker.js").catch(console.error);
  });
}

loadJobs();
