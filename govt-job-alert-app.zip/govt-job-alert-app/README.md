# Sarkari Alert — Govt Job Notification App

A starter app that polls Indian **Central + State government** websites for new
job notifications, stores the clean ones (title, org, level, apply link) and
pushes alerts via **Telegram, Email, and in-app push notification**. The
frontend is a **PWA (Progressive Web App)**, so it installs on Android like a
real app — no Play Store needed.

## Honest limits, read this first

- **"Every" government notification isn't realistically possible.** There are
  hundreds of central departments and 28+ state PSC/board sites, each with
  different, changing HTML. This app ships with ~7 real, major sources
  (SSC, UPSC, RRB, IBPS, Employment News, UPPSC, MPPSC) wired up, and an
  **extensible framework** — adding a new source is copy-pasting one block
  in `backend/scrapers/sources.js`.
- **Scraper selectors will need small fixes.** Government sites change their
  page structure without notice. The scrapers are written defensively, but
  expect to open a source's page, inspect the HTML, and tweak a selector
  every so often. See "Fixing a scraper" below — it takes ~5 minutes.
- **I can't host a live server for you.** I don't have the ability to deploy
  and keep a server running after this chat ends. Below are the exact steps
  to get it live yourself, free, in about 15–20 minutes.
- **Respect each site's terms of use** and keep the polite request delay
  (`REQUEST_DELAY_MS`) — this is for personal/informational aggregation, not
  high-frequency scraping.

## What you get

```
govt-job-alert-app/
├── backend/           Node.js + Express + SQLite scraper & API
│   ├── server.js       REST API + serves the frontend
│   ├── cron.js          Runs the scraper automatically every 30 min
│   ├── db.js             SQLite storage (jobs.db, auto-created)
│   ├── scrapers/
│   │   ├── sources.js    List of government sites to poll (edit here)
│   │   └── scraper.js    Fetches, parses, dedupes, stores
│   └── notify/
│       ├── telegram.js
│       ├── email.js
│       └── webpush.js
└── frontend/           Installable PWA (works on Android/iOS/desktop)
    ├── index.html
    ├── app.js
    ├── style.css
    ├── manifest.json
    ├── service-worker.js
    └── icons/
```

## 1. Run it on your computer first

Requires [Node.js 18+](https://nodejs.org).

```bash
cd backend
npm install
cp .env.example .env
# open .env and fill in at least one notification channel (see step 2)
npm start
```

Open `http://localhost:4000` in your browser — you'll see the job list UI.
It'll be empty until the first scrape finishes (check the terminal logs).

To force a scrape immediately instead of waiting for the cron timer:
```bash
curl -X POST http://localhost:4000/api/scrape-now
```

## 2. Set up notification channels

You don't need all three — enable whichever you want in `.env`.

**Telegram** (easiest, recommended):
1. Open Telegram, message **@BotFather**, send `/newbot`, follow prompts →
   copy the token into `TELEGRAM_BOT_TOKEN`.
2. Message your new bot once (so it's allowed to message you back), then
   visit `https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates` in a browser
   to find your numeric `chat.id` → put it in `TELEGRAM_CHAT_ID`.

**Email**: use a Gmail account with a generated
[App Password](https://myaccount.google.com/apppasswords) (not your normal
password) in `SMTP_PASS`.

**Web push (in-app alerts)**: generate a key pair once:
```bash
npx web-push generate-vapid-keys
```
Copy the two keys into `VAPID_PUBLIC_KEY` / `VAPID_PRIVATE_KEY`.

## 3. Deploy it live (free) so it runs 24/7

The backend also serves the frontend, so one deployment covers both.

1. Push the `govt-job-alert-app` folder to a new GitHub repo.
2. Go to [render.com](https://render.com) → **New → Web Service** → connect
   the repo.
   - Root directory: `backend`
   - Build command: `npm install`
   - Start command: `npm start`
   - Add all your `.env` values under **Environment**.
3. Render gives you a live URL like `https://sarkari-alert.onrender.com`.
   That's your live app — open it on any phone browser.

*(Railway, Fly.io, or a small VPS work the same way if you prefer them.)*

## 4. Install it on Android (turns it into a real app icon)

1. On the Android phone, open **Chrome** and go to your live URL (or
   `http://<your-computer-IP>:4000` if testing on the same WiFi network).
2. Tap the **⋮ menu** → **"Install app"** (or "Add to Home screen").
3. Confirm — an app icon appears on the home screen, opens full-screen with
   no browser bar, and works like a native app.
4. Inside the app, tap **"Enable alerts"** once to allow push notifications —
   new job postings will then show up as real Android notifications, even
   when the app isn't open.

This PWA approach was chosen over a native `.apk` because it installs
instantly with no Play Store review, works identically on any Android phone,
and still gives you a home-screen icon, offline caching, and push
notifications. If you later want a true native app (e.g. to publish on the
Play Store), the same backend API can be wrapped in a minimal Android Studio
WebView project or rebuilt in React Native/Flutter — say the word and I can
scaffold that separately.

## 5. Fixing a scraper (when a site changes its layout)

1. Open the source's URL in Chrome on desktop.
2. Right-click a job notification link → **Inspect**.
3. Note the repeating container element (e.g. each `<tr>` or `<li>` that
   holds one notification) — that's your new `rowSelector`.
4. Note the element with the title text → `titleSelector`, and the `<a>` tag
   → `linkSelector`.
5. Update the matching block in `backend/scrapers/sources.js`, restart the
   server (or redeploy).

## 6. Adding more states / sources

Duplicate any block in `backend/scrapers/sources.js`:

```js
{
  name: "Your State PSC",
  url: "https://example-state-psc.gov.in/notifications",
  level: "State",
  state: "Your State",
  category: "PSC",
  rowSelector: "table tr",
  titleSelector: "td",
  linkSelector: "a",
},
```

## Tech summary

- **Backend**: Node.js, Express, better-sqlite3 (no external DB to manage),
  cheerio (HTML parsing), node-cron (scheduling), node-telegram-bot-api,
  nodemailer, web-push.
- **Frontend**: Vanilla JS PWA (no build step needed) — installable, offline
  cache, native Android push notifications.
- **Storage**: single `jobs.db` SQLite file, created automatically.
